# Cody's Quality Detailing - Design Style Guide

## Design Philosophy

### Visual Language
**Modern Professional Automotive Aesthetic**
- Clean, precision-focused design reflecting automotive excellence
- High-contrast elements emphasizing quality and attention to detail
- Streamlined layouts that mirror the smooth surfaces of detailed vehicles
- Professional credibility balanced with approachable service

### Color Palette
**Primary Colors:**
- **Cyan**: #00B4D8 (Primary accent, CTA buttons, highlights)
- **Black**: #000000 (Primary text, backgrounds, contrast elements)
- **White**: #FFFFFF (Backgrounds, text on dark, clean spaces)

**Supporting Colors:**
- **Light Gray**: #F8F9FA (Section backgrounds, subtle dividers)
- **Dark Gray**: #2D3748 (Secondary text, form borders)
- **Cyan Light**: #90E0EF (Hover states, subtle accents)

### Typography
**Primary Font**: Inter (Sans-serif)
- **Display**: Inter Bold 700 (Headings, hero text)
- **Body**: Inter Regular 400 (Content text)
- **Accent**: Inter Medium 500 (Buttons, labels)

**Hierarchy:**
- H1: 2.5rem (40px) - Hero headlines
- H2: 2rem (32px) - Section headers
- H3: 1.5rem (24px) - Subsection headers
- Body: 1rem (16px) - Standard text
- Small: 0.875rem (14px) - Captions, metadata

## Visual Effects

### Used Libraries
- **Anime.js**: Smooth element animations and transitions
- **Typed.js**: Dynamic text effects for hero headlines
- **Splide**: Image carousels and galleries
- **ECharts.js**: Data visualization for booking analytics
- **p5.js**: Creative background effects

### Effect Implementation

#### Header Background Effect
- **Liquid Metal Displacement**: Subtle animated background using p5.js
- Colors: Deep black with cyan accent particles
- Movement: Slow, flowing motion suggesting precision and care

#### Text Effects
- **Typewriter Animation**: Hero headline appears letter by letter
- **Color Cycling**: Business name alternates between cyan and white
- **Stagger Animation**: Service cards animate in sequence on scroll

#### Interactive Elements
- **Button Hover**: Cyan background with white text, subtle scale increase
- **Card Hover**: Lift effect with cyan border glow
- **Image Hover**: Zoom with cyan overlay fade-in

#### Loading States
- **Skeleton Screens**: Gray placeholders while content loads
- **Progress Indicators**: Cyan progress bars for form submissions
- **Spinner Animation**: Rotating cyan circle for processing states

### Animation Principles
- **Duration**: 300-500ms for micro-interactions
- **Easing**: cubic-bezier(0.4, 0.0, 0.2, 1) for natural motion
- **Stagger**: 100ms delays between sequential elements
- **Parallax**: Subtle 8% translateY on background elements

## Layout System

### Grid Structure
- **Mobile**: Single column, full-width containers
- **Breakpoints**: 
  - sm: 640px
  - md: 768px  
  - lg: 1024px
  - xl: 1280px

### Spacing Scale
- **xs**: 0.25rem (4px)
- **sm**: 0.5rem (8px)
- **md**: 1rem (16px)
- **lg**: 1.5rem (24px)
- **xl**: 2rem (32px)
- **2xl**: 3rem (48px)

### Component Styling

#### Buttons
- **Primary**: Cyan background, white text, rounded corners
- **Secondary**: Black outline, cyan text, transparent background
- **Ghost**: Transparent with cyan text, hover fill

#### Cards
- **Service Cards**: White background, subtle shadow, cyan accent border
- **Review Cards**: Light gray background, rounded corners, star ratings
- **Image Cards**: Full-bleed images with cyan overlay on hover

#### Forms
- **Inputs**: White background, dark gray border, cyan focus ring
- **Labels**: Dark gray text, medium weight
- **Validation**: Red error states, green success states

## Imagery Guidelines

### Photography Style
- **High Contrast**: Sharp, detailed images showcasing automotive perfection
- **Professional Lighting**: Clean, well-lit before/after shots
- **Consistent Framing**: Standardized angles for service comparisons
- **Color Grading**: Slightly cool temperature to match cyan theme

### Icon System
- **Style**: Outline icons with 2px stroke weight
- **Color**: Cyan for active states, dark gray for inactive
- **Size**: 24px standard, 32px for feature highlights

## Accessibility Standards

### Color Contrast
- **Text on White**: Minimum 4.5:1 ratio (dark gray text)
- **Text on Black**: Minimum 4.5:1 ratio (white text)
- **Cyan Elements**: Tested for color blindness compatibility

### Interactive Elements
- **Touch Targets**: Minimum 44px for mobile interaction
- **Focus States**: Clear cyan outline for keyboard navigation
- **Screen Reader**: Proper ARIA labels and semantic HTML