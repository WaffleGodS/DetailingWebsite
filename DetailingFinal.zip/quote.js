class QuoteRequestHandler {
    constructor() { this.form = document.getElementById('quote-request-form'); this.init(); }

    init() { if (this.form) this.form.addEventListener('submit', (e) => this.handleSubmit(e)); }

    handleSubmit(event) {
        event.preventDefault();
        const formData = new FormData(this.form);
        const quoteRequest = {
            id: 'quote_' + Date.now(), timestamp: new Date().toISOString(), status: 'new',
            customer: { name: formData.get('name'), phone: formData.get('phone'), email: formData.get('email') || 'N/A', car: formData.get('car') },
            service: formData.get('service'), message: formData.get('message') || 'No message provided.',
        };
        if (!quoteRequest.customer.name || !quoteRequest.customer.phone || !quoteRequest.customer.car || !quoteRequest.service) {
            alert('Please fill in all required fields (*).'); return;
        }
        this.saveQuoteRequest(quoteRequest); this.showConfirmation(quoteRequest); this.form.reset();
        document.querySelectorAll('.service-option').forEach(option => option.classList.remove('selected'));
    }

    saveQuoteRequest(quoteData) {
        try {
            const data = JSON.parse(localStorage.getItem('cody_detailing_data')) || {};
            if (!data.quoteRequests) data.quoteRequests = [];
            data.quoteRequests.unshift(quoteData); 
            localStorage.setItem('cody_detailing_data', JSON.stringify(data));
        } catch (error) { console.error('Failed to save quote request:', error); }
    }

    showConfirmation(quoteData) {
        const existingModal = document.querySelector('.confirmation-modal'); if (existingModal) existingModal.remove();
        const modal = document.createElement('div');
        modal.className = 'confirmation-modal fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4';
        modal.innerHTML = `
            <div class="bg-white p-8 rounded-lg max-w-md w-full text-gray-800"><div class="text-center mb-6"><div class="text-green-500 text-6xl mb-4">✓</div>
            <h3 class="text-2xl font-bold mb-2">Request Sent!</h3><p class="text-gray-600">Thank you, ${quoteData.customer.name}. We've received your request.</p></div>
            <div class="bg-cyan-50 p-4 rounded-lg mb-6"><p class="text-sm text-cyan-800 text-center">We will contact you within 24 hours to provide your personalized quote.</p></div>
            <button onclick="this.parentElement.parentElement.remove()" class="w-full bg-cyan-500 text-white py-3 rounded-lg hover:bg-cyan-600 font-semibold">Close</button></div>`;
        document.body.appendChild(modal);
    }
}
document.addEventListener('DOMContentLoaded', () => { new QuoteRequestHandler(); });
