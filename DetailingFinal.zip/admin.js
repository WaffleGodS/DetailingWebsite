class AdminPanel {
    constructor() {
        this.init();
    }

    init() {
        document.addEventListener('DOMContentLoaded', () => {
            this.initializeData(); // This is the new function call
            if (localStorage.getItem('cody_admin_session') === 'true') {
                this.showDashboard();
            } else {
                this.showLogin();
            }
            this.attachEventListeners();
        });
    }

    // New function to create default data if none exists
    initializeData() {
        if (!localStorage.getItem('cody_detailing_data')) {
            console.log("No data found. Initializing default data structure.");
            const defaultData = {
                businessInfo: { name: "Cody's Quality Detailing", phone: "", email: "", hours: "", address: "" },
                services: [],
                quoteRequests: [],
                gallery: [],
                aboutContent: { title: "About Us", content: "Welcome to our page!" }
            };
            this.saveData(defaultData);
        }
    }

    attachEventListeners() {
        document.getElementById('admin-login-form')?.addEventListener('submit', (e) => { e.preventDefault(); this.handleLogin(); });
        document.querySelectorAll('.tab-button').forEach(btn => btn.addEventListener('click', (e) => this.handleTabClick(e.target)));
        document.getElementById('settings-form')?.addEventListener('submit', (e) => this.saveSettings(e));
    }

    handleLogin() {
        if (document.getElementById('admin-username').value === 'csillavan' && document.getElementById('admin-password').value === 'Sillavan2@@6') {
            localStorage.setItem('cody_admin_session', 'true');
            this.showDashboard();
        } else {
            alert('Invalid credentials');
        }
    }

    logout() {
        localStorage.removeItem('cody_admin_session');
        window.location.reload();
    }

    showLogin() {
        document.getElementById('admin-login').style.display = 'flex';
        document.getElementById('admin-dashboard').style.display = 'none';
        const navActions = document.getElementById('admin-nav-actions');
        if (navActions) navActions.style.display = 'none';
    }

    showDashboard() {
        document.getElementById('admin-login').style.display = 'none';
        document.getElementById('admin-dashboard').style.display = 'block';
        const navActions = document.getElementById('admin-nav-actions');
        if (navActions) navActions.style.display = 'flex';
        this.handleTabClick(document.querySelector('.tab-button.active'));
    }

    handleTabClick(clickedButton) {
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active', 'bg-cyan-500');
            btn.classList.add('bg-gray-700');
        });
        clickedButton.classList.add('active', 'bg-cyan-500');
        clickedButton.classList.remove('bg-gray-700');
        
        const tabMap = {
            'Dashboard': 'dashboard',
            'Quote Requests': 'quotes',
            'Services': 'services',
            'Gallery': 'gallery',
            'About Us': 'about',
            'Settings': 'settings'
        };
        const tabKey = tabMap[clickedButton.textContent.trim()];

        document.querySelectorAll('.tab-content').forEach(tab => tab.classList.add('hidden'));
        const activeTab = document.getElementById(`${tabKey}-tab`);
        if (activeTab) {
            activeTab.classList.remove('hidden');
            this.loadTabContent(tabKey);
        }
    }

    loadTabContent(tabKey) {
        const data = this.getData();
        if (!data) return;

        switch (tabKey) {
            case 'dashboard': this.loadDashboard(data); break;
            case 'quotes': this.loadQuotes(data); break;
            case 'services': this.loadServices(data); break;
            case 'gallery': this.loadGallery(data); break;
            case 'about': this.loadAbout(data); break;
            case 'settings': this.loadSettings(data); break;
        }
    }

    getData() {
        try {
            return JSON.parse(localStorage.getItem('cody_detailing_data')) || {};
        } catch (e) {
            console.error("Error parsing data from localStorage:", e);
            return {};
        }
    }

    saveData(data) {
        localStorage.setItem('cody_detailing_data', JSON.stringify(data));
    }
    
    getServiceName(data, serviceId) {
        const service = (data.services || []).find(s => s.id === serviceId);
        return service ? service.name : 'Unknown Service';
    }

    loadDashboard(data) {
        const requests = data.quoteRequests || [];
        document.getElementById('total-requests').textContent = requests.length;
        document.getElementById('contacted-requests').textContent = requests.filter(q => q.status === 'contacted').length;
        document.getElementById('pending-requests').textContent = requests.filter(q => q.status === 'new').length;
        this.initChart(data);
    }

    loadQuotes(data) {
        const requests = data.quoteRequests || [];
        const container = document.getElementById('quote-requests-list');
        if (requests.length === 0) {
            container.innerHTML = `<p class="text-gray-500">No quote requests found.</p>`;
            return;
        }
        container.innerHTML = requests.map(quote => `
            <div class="border rounded-lg p-4 mb-4 bg-gray-50">
                <div class="flex justify-between items-start">
                    <div>
                        <h3 class="font-semibold">${quote.customer.name} - ${quote.customer.car}</h3>
                        <p class="text-sm text-gray-600">Phone: ${quote.customer.phone}</p>
                        <p class="text-sm text-cyan-600 font-medium">${this.getServiceName(data, quote.service)}</p>
                    </div>
                    <span class="text-xs font-medium px-2 py-1 rounded-full ${quote.status === 'contacted' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}">${quote.status}</span>
                </div>
                <div class="text-sm mt-2 pt-2 border-t">${quote.message}</div>
                <div class="flex space-x-2 mt-4">
                    <button onclick="window.adminPanel.updateQuoteStatus('${quote.id}', 'contacted')" class="px-3 py-1 bg-green-500 text-white rounded text-sm hover:bg-green-600">Mark Contacted</button>
                    <button onclick="window.adminPanel.deleteQuote('${quote.id}')" class="px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600">Delete</button>
                </div>
            </div>`).join('');
    }

    loadServices(data) {
        const services = data.services || [];
        const container = document.getElementById('services-list');
        container.innerHTML = services.map(s => `
            <div class="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <h3 class="font-semibold text-lg">${s.name}</h3>
                        <p class="text-cyan-600 font-semibold">$${s.price.min} - $${s.price.max}</p>
                    </div>
                    <div class="flex space-x-2">
                        <button onclick="window.adminPanel.editService('${s.id}')" class="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600">Edit</button>
                        <button onclick="window.adminPanel.deleteService('${s.id}')" class="px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600">Delete</button>
                    </div>
                </div>
                <p class="text-sm text-gray-600">${s.description}</p>
            </div>`).join('');
    }

    addNewService() {
        const name = prompt("Enter new service name:");
        if (!name) return;
        const newService = {
            id: 'service_' + Date.now(),
            name: name,
            price: {
                min: parseInt(prompt("Enter minimum price:", "100"), 10),
                max: parseInt(prompt("Enter maximum price:", "200"), 10)
            },
            description: prompt("Enter service description:")
        };
        const data = this.getData();
        data.services.push(newService);
        this.saveData(data);
        this.loadServices(data);
    }

    editService(serviceId) {
        let data = this.getData();
        const service = (data.services || []).find(s => s.id === serviceId);
        if (!service) return;
        service.name = prompt("Edit service name:", service.name) || service.name;
        service.price.min = parseInt(prompt("Edit minimum price:", service.price.min), 10) || service.price.min;
        service.price.max = parseInt(prompt("Edit maximum price:", service.price.max), 10) || service.price.max;
        service.description = prompt("Edit service description:", service.description) || service.description;
        this.saveData(data);
        this.loadServices(data);
    }

    deleteService(serviceId) {
        if (confirm('Are you sure you want to delete this service?')) {
            let data = this.getData();
            data.services = (data.services || []).filter(s => s.id !== serviceId);
            this.saveData(data);
            this.loadServices(data);
        }
    }

    loadGallery(data) {
        const albums = data.gallery || [];
        const container = document.getElementById('albums-list');
        container.innerHTML = albums.map(album => `
            <div class="border rounded-lg p-4 bg-gray-50">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="font-bold text-xl">${album.name}</h3>
                    <div>
                        <button onclick="window.adminPanel.addPhotoToAlbum('${album.id}')" class="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600">Add Photo</button>
                        <button onclick="window.adminPanel.deleteAlbum('${album.id}')" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600 ml-2">Delete Album</button>
                    </div>
                </div>
                <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                    ${album.photos.map(photo => `
                        <div class="relative group">
                            <img src="${photo.url}" class="w-full h-32 object-cover rounded-lg">
                            <div class="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onclick="window.adminPanel.deletePhoto('${album.id}', '${photo.id}')" class="text-white text-xs bg-red-600 px-2 py-1 rounded">Delete</button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');
    }

    createNewAlbum() {
        const name = prompt("Enter new album name:");
        if (!name) return;
        const newAlbum = { id: 'album_' + Date.now(), name, photos: [] };
        const data = this.getData();
        data.gallery.push(newAlbum);
        this.saveData(data);
        this.loadGallery(data);
    }

    deleteAlbum(albumId) {
        if (confirm('Are you sure you want to delete this entire album?')) {
            let data = this.getData();
            data.gallery = data.gallery.filter(a => a.id !== albumId);
            this.saveData(data);
            this.loadGallery(data);
        }
    }

    addPhotoToAlbum(albumId) {
        const url = prompt("Enter the image URL for the new photo:");
        if (!url) return;
        const newPhoto = { id: 'photo_' + Date.now(), url };
        let data = this.getData();
        const album = data.gallery.find(a => a.id === albumId);
        if (album) {
            album.photos.push(newPhoto);
            this.saveData(data);
            this.loadGallery(data);
        }
    }

    deletePhoto(albumId, photoId) {
        if (confirm('Are you sure you want to delete this photo?')) {
            let data = this.getData();
            const album = data.gallery.find(a => a.id === albumId);
            if (album) {
                album.photos = album.photos.filter(p => p.id !== photoId);
                this.saveData(data);
                this.loadGallery(data);
            }
        }
    }

    loadAbout(data) {
        const about = data.aboutContent || {};
        document.getElementById('about-title').value = about.title || '';
        document.getElementById('about-content-editor').value = about.content || '';
    }

    saveAboutContent() {
        const data = this.getData();
        data.aboutContent = {
            title: document.getElementById('about-title').value,
            content: document.getElementById('about-content-editor').value
        };
        this.saveData(data);
        alert('About content saved!');
    }

    loadSettings(data) {
        const info = data.businessInfo || {};
        document.getElementById('business-name').value = info.name || '';
        document.getElementById('business-phone').value = info.phone || '';
        document.getElementById('business-email').value = info.email || '';
        document.getElementById('business-hours').value = info.hours || '';
        document.getElementById('business-address').value = info.address || '';
    }

    saveSettings(e) {
        e.preventDefault();
        const data = this.getData();
        data.businessInfo = {
            name: document.getElementById('business-name').value,
            phone: document.getElementById('business-phone').value,
            email: document.getElementById('business-email').value,
            hours: document.getElementById('business-hours').value,
            address: document.getElementById('business-address').value
        };
        this.saveData(data);
        alert('Settings Saved!');
    }

    updateQuoteStatus(quoteId, status) {
        const data = this.getData();
        const quote = (data.quoteRequests || []).find(q => q.id === quoteId);
        if (quote) {
            quote.status = status;
            this.saveData(data);
            this.loadQuotes(data);
            this.loadDashboard(data); // Refresh dashboard stats
        }
    }

    deleteQuote(quoteId) {
        if (confirm('Are you sure you want to delete this quote request?')) {
            let data = this.getData();
            data.quoteRequests = (data.quoteRequests || []).filter(q => q.id !== quoteId);
            this.saveData(data);
            this.loadQuotes(data);
            this.loadDashboard(data); // Refresh dashboard stats
        }
    }

    initChart(data) {
        const container = document.getElementById('quote-chart');
        if (!container || !window.echarts) return;
        
        const requests = data.quoteRequests || [];
        if (requests.length === 0) {
            container.innerHTML = '<p class="text-center text-gray-500">No data available for chart.</p>';
            return;
        }

        const serviceCounts = requests.reduce((acc, quote) => {
            const name = this.getServiceName(data, quote.service);
            acc[name] = (acc[name] || 0) + 1;
            return acc;
        }, {});

        const chartData = Object.entries(serviceCounts).map(([name, value]) => ({ name, value }));
        
        if (this.chart) {
            this.chart.dispose();
        }
        this.chart = echarts.init(container);
        this.chart.setOption({
            tooltip: { trigger: 'item' },
            legend: { top: '5%', left: 'center' },
            series: [{
                name: 'Service Requests',
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
                itemStyle: {
                    borderRadius: 10,
                    borderColor: '#fff',
                    borderWidth: 2
                },
                label: { show: false, position: 'center' },
                emphasis: { label: { show: true, fontSize: '20', fontWeight: 'bold' } },
                labelLine: { show: false },
                data: chartData
            }]
        });
    }
}

window.adminPanel = new AdminPanel();


