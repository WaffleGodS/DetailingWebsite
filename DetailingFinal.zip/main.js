class CodyDetailingApp {
    constructor() { this.init(); }
    init() { document.addEventListener('DOMContentLoaded', () => { this.initLocalStorage(); this.initEventListeners(); this.initAnimations(); }); }

    initLocalStorage() {
        if (localStorage.getItem('cody_detailing_data')) return;
        const defaultData = {
            quoteRequests: [],
            aboutContent: { title: "Our Story", content: `<h3>Welcome to Cody's Quality Detailing</h3><p>Founded on the principles of quality, integrity, and exceptional customer service, we provide professional mobile auto detailing services with a personal touch.</p><p><em>This content can be changed in the 'About Us' tab of the admin panel.</em></p>` },
            services: [
                { id: 'interior', name: 'Interior Detailing', price: { min: 200, max: 300 }, duration: "3-4 hours", description: "Complete interior restoration service that brings your vehicle's interior back to showroom condition.", features: ["Full wipedown of all interior surfaces", "Vacuuming of whole interior", "Leather conditioning", "Streak-free glass cleaning", "Clean door jambs"] },
                { id: 'exterior', name: 'Premium Exterior Detailing', price: { min: 150, max: 250 }, duration: "2-3 hours", description: "Professional exterior cleaning and protection that enhances your vehicle's appearance and preserves its finish.", features: ["Engine bay cleaned", "Hand washing with premium products", "Wheels and tires hand washed", "Removal of bugs and road grime", "Tire dressing applied for fresh shine"] },
                { id: 'full', name: 'Full Detail Package', price: { min: 350, max: 500 }, duration: "5-6 hours", description: "Our comprehensive detailing package combining interior and exterior services at a discounted rate for complete vehicle transformation.", features: ["Includes all interior services", "Includes all exterior services", "Paint protection application", "Engine bay detailing", "Premium wax finish"] },
                { id: 'maintenance', name: 'Maintenance Package', price: { min: 75, max: 150 }, duration: "1-2 hours", description: "Ongoing maintenance program for valued customers who want to keep their vehicles in pristine condition year-round.", features: ["For repeat customers only", "Monthly or bi-monthly schedules", "Price-lock guarantee for 3 years", "Cancel anytime flexibility", "Custom pricing based on frequency"] }
            ],
            reviews: [ { id: 'review1', name: 'Sarah J.', comment: 'Incredible attention to detail. My car looks brand new!', rating: 5}, { id: 'review2', name: 'Mike C.', comment: 'Professional, convenient, and worth every penny. Highly recommend!', rating: 5} ],
            businessInfo: { name: "Cody's Quality Detailing", phone: '(360) 632-8982', email: 'codysqualitydetailing@gmail.com', hours: 'Mon - Sat: 8AM - 6PM', address: 'Serving the greater metropolitan area and surrounding communities.' }
        };
        localStorage.setItem('cody_detailing_data', JSON.stringify(defaultData));
    }

    initEventListeners() {
        const mobileMenuBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        if (mobileMenuBtn && mobileMenu) mobileMenuBtn.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
        }, { threshold: 0.1 });
        document.querySelectorAll('.animate-on-scroll').forEach(el => observer.observe(el));
    }

    initAnimations() {
        if (typeof Typed !== 'undefined' && document.getElementById('hero-text')) {
            new Typed('#hero-text', { strings: ["Cody's Quality Detailing", "Professional Auto Care", "Excellence in Every Detail"], typeSpeed: 50, backSpeed: 30, backDelay: 2000, loop: true });
        }
    }
}
window.app = new CodyDetailingApp();
